﻿using System;

namespace Prac1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[8];
            NoOdds();
            
            void NoOdds() {
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine("Input elements");
                    arr[i] = int.Parse(Console.ReadLine());
                }

                Console.WriteLine("Even numbers- ");
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i] % 2 == 0)
                    {
                        Console.WriteLine(arr[i] + " ");
                    }
                }
                Console.ReadLine();
            }
           

        }

    }
}
