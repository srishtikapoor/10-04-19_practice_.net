﻿using System;

namespace Prac2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[4];
            SumSmallest();
            void SumSmallest(){
                Console.WriteLine("Enter numbers for an array");
              
                for (int i = 0; i < arr.Length; i++)
                {
                        arr[i] = int.Parse(Console.ReadLine());
                    
                }

                
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    for (int j = i + 1; j < arr.Length; j++)
                    {
                        if (arr[i] > arr[j])
                        {
                            int temp = arr[i];
                            arr[i] = arr[j];
                            arr[j] = temp;
                        }

                    }
                }
                Console.WriteLine(arr[0]);
                Console.WriteLine(arr[1]);
                Console.WriteLine("sum is:" + (arr[1] + arr[0]));
            }
            Console.Read();

           
           
        }
    }
}